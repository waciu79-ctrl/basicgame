basicgame by funnyboy3

don't run as administrator for safe version
run as administrator for unsafe version