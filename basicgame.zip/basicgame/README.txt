basicgame by funnyboy3

please run as administrator
when prompted type yes to turn on unsafe mode
and type no to not turn on unsafe mode