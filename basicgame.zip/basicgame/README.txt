basicgame by funnyboy3

please run as administrator
when prompted types yes to execute
and type no to cancel execution